#!/bin/bash
# Set up home directory files
mkdir -p /home/user/zhangben
echo "This is the zhangdan file content - confidential account data." > /home/user/zhangben/zhangdan
echo "This is the youjian attachment file." > /home/user/youjian
mkdir -p /home/user/xingxing
mkdir -p /home/user/Zhongyao
mkdir -p /home/user/Home
# cat placeholder for desktop cat image
touch /home/user/Desktop/cat.png
echo "[INFO] Home directory files set up"
