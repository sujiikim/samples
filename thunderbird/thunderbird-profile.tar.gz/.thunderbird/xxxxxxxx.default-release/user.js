// Startup overrides - applied every launch, cannot be changed via UI
// Only wizard/onboarding suppression here; account config is in prefs.js

user_pref("mail.provider.enabled", false);
user_pref("mailnews.start_page.enabled", false);
user_pref("mailnews.start_page_override.mstone", "115.10.1");
user_pref("mail.setup.wizard.enabled", false);
user_pref("mail.accountsetup.onboarding.enabled", false);
user_pref("mail.whats_new_page.enabled", false);
user_pref("mail.spotlight.shouldPresentMailFeatureTour", false);
user_pref("messenger.startup.action", 0);
user_pref("mail.rights.version", 3);
user_pref("mail.rights.3.shown", true);
user_pref("datareporting.policy.dataSubmissionPolicyBypassNotification", true);
user_pref("toolkit.telemetry.reportingpolicy.firstRun", false);
user_pref("app.normandy.first_run", false);
user_pref("mail.check_new_mail", false);
user_pref("app.donation.eoy.version.viewed", 5);
user_pref("extensions.lastAppVersion", "115.10.1");
user_pref("extensions.lastAppBuildId", "20240417192958");
user_pref("extensions.lastPlatformVersion", "115.10.0");
user_pref("startup.homepage_welcome_url", "");
user_pref("startup.homepage_welcome_url.additional", "");
