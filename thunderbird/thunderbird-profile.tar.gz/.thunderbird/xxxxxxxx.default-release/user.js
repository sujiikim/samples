// Force settings that cannot be overridden by TB initialization
// This file is read on every startup and overrides prefs.js

// Suppress all first-run / onboarding UI
user_pref("mail.provider.enabled", false);
user_pref("mailnews.start_page.enabled", false);
user_pref("mail.rights.version", 1);
user_pref("mail.spotlight.shouldPresentMailFeatureTour", false);
user_pref("toolkit.telemetry.reportingpolicy.firstRun", false);
user_pref("datareporting.policy.dataSubmissionPolicyBypassNotification", true);
user_pref("app.normandy.first_run", false);

// Ensure accounts are recognized
user_pref("mail.accountmanager.accounts", "account1,account2,account3,account4,account5");
user_pref("mail.accountmanager.defaultaccount", "account1");
user_pref("mail.accountmanager.localfoldersserver", "server3");

// Suppress "Set Up Your Existing Email Address" tab
// This key prevents the new account wizard from opening on startup
user_pref("mail.account.account1.server", "server1");
user_pref("mail.account.account2.server", "server2");

// TB 115+ / 128+ onboarding hub suppression
user_pref("mail.accountsetup.onboarding.enabled", false);
user_pref("mail.setup.wizard.enabled", false);
// 이 탭이 열리는 건 messenger.startup.action과 관련
// 0 = 아무것도 안함, 1 = 메시지창, 2 = 작성창
user_pref("messenger.startup.action", 0);
// welcome page
user_pref("mailnews.start_page.url", "");
// 새 계정 자동감지 비활성화
user_pref("mail.provider.enabled", false);
// TB 128: "What's new" 탭
user_pref("app.update.channel", "default");
user_pref("mail.whats_new_page.enabled", false);
