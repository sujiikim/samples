#!/bin/bash
# Thunderbird profile installer for OSWorld synthetic dataset
set -e

echo "[INFO] Installing Thunderbird..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq 2>/dev/null
apt-get install -y -qq thunderbird 2>/dev/null

echo "[INFO] Setting up Thunderbird profile..."

# Determine target home directory
TARGET_HOME="${HOME:-/home/user}"
TB_DIR="$TARGET_HOME/.thunderbird"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROFILE_SRC="$SCRIPT_DIR/thunderbird-profile"

# Create profile directory
mkdir -p "$TB_DIR"

# Deploy profiles.ini
cp "$PROFILE_SRC/thunderbird/profiles.ini" "$TB_DIR/"

# Deploy profile
if [ -d "$TB_DIR/xxxxxxxx.default-release" ]; then
    rm -rf "$TB_DIR/xxxxxxxx.default-release"
fi
cp -r "$PROFILE_SRC/thunderbird/xxxxxxxx.default-release" "$TB_DIR/"

# Fix calendar ICS URI to match actual home directory
sed -i "s|file:///home/user/\.thunderbird|file://${TB_DIR}|g" \
    "$TB_DIR/xxxxxxxx.default-release/prefs.js"

# Set up home directory files
mkdir -p "$TARGET_HOME/zhangben"
echo "This is the zhangdan file - confidential." > "$TARGET_HOME/zhangben/zhangdan"
echo "This is the youjian file." > "$TARGET_HOME/youjian"
mkdir -p "$TARGET_HOME/xingxing"
mkdir -p "$TARGET_HOME/Zhongyao"
mkdir -p "$TARGET_HOME/Home"
mkdir -p "$TARGET_HOME/Desktop"
# Placeholder cat image (1x1 PNG)
printf '\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82' \
    > "$TARGET_HOME/Desktop/cat.png"

# Fix permissions
chown -R "${USER:-user}:${USER:-user}" "$TB_DIR" 2>/dev/null || true
chown -R "${USER:-user}:${USER:-user}" "$TARGET_HOME/zhangben" 2>/dev/null || true

echo "[INFO] Thunderbird profile installed at: $TB_DIR"
echo "[INFO] Profile ID: xxxxxxxx.default-release"
echo "[INFO] Accounts: yanlin451200@gmail.com, 852736397@qq.com, test@t11.com, anonym-x2024@outlook.com"
echo "[INFO] Done."
