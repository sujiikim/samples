#!/bin/bash
# Thunderbird profile installer
set -e

echo "[INFO] Installing Thunderbird..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq 2>/dev/null
apt-get install -y -qq thunderbird 2>/dev/null

echo "[INFO] Setting up Thunderbird profile..."

TARGET_HOME="${HOME:-/home/user}"
TB_DIR="$TARGET_HOME/.thunderbird"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROFILE_SRC="$SCRIPT_DIR/thunderbird-profile"

mkdir -p "$TB_DIR"

# Deploy profiles.ini
cp "$PROFILE_SRC/thunderbird/profiles.ini" "$TB_DIR/"

# Deploy profile
rm -rf "$TB_DIR/xxxxxxxx.default-release"
cp -r "$PROFILE_SRC/thunderbird/xxxxxxxx.default-release" "$TB_DIR/"

# Fix calendar URI
sed -i "s|file:///home/user/\.thunderbird|file://${TB_DIR}|g" \
    "$TB_DIR/xxxxxxxx.default-release/prefs.js"

# Get Thunderbird install hash and inject Install section into profiles.ini
TB_INSTALL_DIR=$(dirname "$(readlink -f "$(which thunderbird)")")
# Try common paths
for d in /usr/lib/thunderbird /usr/lib/thunderbird-bin /opt/thunderbird; do
    [ -d "$d" ] && TB_INSTALL_DIR="$d" && break
done

# Compute install hash from TB directory (TB uses SHA1 of path, but we can 
# let TB create it on first run - just ensure profile is selected via Default=1)
# The key fix is: compatibility.ini must match installed TB version
TB_VERSION=$(thunderbird --version 2>/dev/null | grep -oP '[\d.]+' | head -1 || echo "115.0")
cat > "$TB_DIR/xxxxxxxx.default-release/compatibility.ini" << COMPEOF
[Compatibility]
LastVersion=${TB_VERSION}
LastOSABI=Linux_x86_64-gcc3
LastPlatformDir=${TB_INSTALL_DIR}
LastAppDir=${TB_INSTALL_DIR}
COMPEOF

# Fix times.json with realistic past timestamp
echo '{"created":1700000000000,"firstUse":1700000000000}' \
    > "$TB_DIR/xxxxxxxx.default-release/times.json"

# Home directory files
mkdir -p "$TARGET_HOME/zhangben"
echo "This is the zhangdan file - confidential." > "$TARGET_HOME/zhangben/zhangdan"
echo "This is the youjian file." > "$TARGET_HOME/youjian"
mkdir -p "$TARGET_HOME/xingxing"
mkdir -p "$TARGET_HOME/Zhongyao"
mkdir -p "$TARGET_HOME/Home"
mkdir -p "$TARGET_HOME/Desktop"
printf '\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82' \
    > "$TARGET_HOME/Desktop/cat.png"

chown -R "${SUDO_USER:-$USER}" "$TB_DIR" 2>/dev/null || true

echo "[INFO] Done. Thunderbird profile installed at: $TB_DIR"
echo "[INFO] Thunderbird version: $TB_VERSION"
