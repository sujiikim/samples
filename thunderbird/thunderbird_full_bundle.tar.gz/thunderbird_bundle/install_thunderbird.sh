#!/bin/bash
set -e

echo "[*] Installing Thunderbird..."
sudo apt-get update
sudo apt-get install -y thunderbird

echo "[*] Extracting profile..."
tar -xzvf thunderbird-profile.tar.gz -C /home/user/

echo "[*] Done. Launching Thunderbird..."
thunderbird
