This bundle includes:
- thunderbird-profile.tar.gz (synthetic profile)
- install_thunderbird.sh (installs Thunderbird + extracts profile)

Usage:
bash install_thunderbird.sh
